import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WeatherAppGUI {

    public static JSONObject getWeatherData(String locationName) {
        JSONArray locationData = getLocationData(locationName);
        if (locationData == null || locationData.isEmpty()) return null;

        JSONObject location = (JSONObject) locationData.get(0);
        double latitude = (double) location.get("latitude");
        double longitude = (double) location.get("longitude");

        String urlString = "https://api.open-meteo.com/v1/forecast?" +
                "latitude=" + latitude + "&longitude=" + longitude +
                "&hourly=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m" +
                "&timezone=auto";

        try {
            HttpURLConnection conn = fetchApiResponse(urlString);
            if (conn == null || conn.getResponseCode() != 200) return null;

            StringBuilder resultJson = new StringBuilder();
            Scanner scanner = new Scanner(conn.getInputStream());
            while (scanner.hasNextLine()) {
                resultJson.append(scanner.nextLine());
            }
            scanner.close();
            conn.disconnect();

            JSONObject resultJsonobj = (JSONObject) new JSONParser().parse(resultJson.toString());
            JSONObject hourly = (JSONObject) resultJsonobj.get("hourly");

            JSONArray time = (JSONArray) hourly.get("time");
            int index = findIndexOfCurrentTime(time);

            JSONArray temperature = (JSONArray) hourly.get("temperature_2m");
            JSONArray weatherCode = (JSONArray) hourly.get("weather_code");
            JSONArray relativeHumidity = (JSONArray) hourly.get("relative_humidity_2m");
            JSONArray windspeedData = (JSONArray) hourly.get("wind_speed_10m");

            JSONObject weatherData = new JSONObject();
            weatherData.put("temperature", (double) temperature.get(index));
            weatherData.put("weatherCondition", convertWeatherCode((long) weatherCode.get(index)));
            weatherData.put("humidity", (long) relativeHumidity.get(index));
            weatherData.put("windspeed", (double) windspeedData.get(index));

            return weatherData;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static JSONArray getLocationData(String locationName) {
        locationName = locationName.replaceAll(" ", "+");
        String urlString = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                locationName + "&count=1&language=en&format=json";

        try {
            HttpURLConnection conn = fetchApiResponse(urlString);
            if (conn == null || conn.getResponseCode() != 200) return null;

            StringBuilder resultJson = new StringBuilder();
            Scanner scanner = new Scanner(conn.getInputStream());
            while (scanner.hasNext()) {
                resultJson.append(scanner.nextLine());
            }
            scanner.close();
            conn.disconnect();

            JSONObject resultJsonobj = (JSONObject) new JSONParser().parse(resultJson.toString());
            return (JSONArray) resultJsonobj.get("results");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static HttpURLConnection fetchApiResponse(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            return conn;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static int findIndexOfCurrentTime(JSONArray time) {
        String currentTime = getCurrentTime();
        for (int i = 0; i < time.size(); i++) {
            if (time.get(i).equals(currentTime)) {
                return i;
            }
        }
        return 0;
    }

    public static String getCurrentTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:00");
        return now.format(formatter);
    }

    private static String convertWeatherCode(long code) {
        if (code == 0L) return "Clear";
        if (code <= 3L) return "Cloudy";
        if ((code >= 51L && code <= 67L) || (code >= 80L && code <= 99L)) return "Rain";
        if (code >= 71L && code <= 77L) return "Snow";
        return "Unknown";
    }
}
