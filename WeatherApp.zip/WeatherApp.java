import org.json.simple.JSONObject;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class WeatherApp extends JFrame {
    private JSONObject weatherData;

    public WeatherApp() throws IOException {
        super("Weather App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 650);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        addComponents();
    }

    private void addComponents() throws IOException {
        JTextField searchField = new JTextField();
        searchField.setBounds(15, 15, 351, 45);
        searchField.setFont(new Font("Dialog", Font.PLAIN, 24));
        add(searchField);

        JLayeredPane weatherLayer = new JLayeredPane();
        weatherLayer.setBounds(0, 100, 450, 217);
        add(weatherLayer);

        JLabel weatherConditionImage = new JLabel();
        try {
            weatherConditionImage.setIcon(loadImage("src/cloudy.png", 450, 217));
        } catch (IOException e) {
            weatherConditionImage.setText("\uD83C\uDF24️");
            weatherConditionImage.setHorizontalAlignment(SwingConstants.CENTER);
            weatherConditionImage.setFont(new Font("Dialog", Font.PLAIN, 100));
        }
        weatherConditionImage.setBounds(0, 0, 450, 217);
        weatherLayer.add(weatherConditionImage, Integer.valueOf(0));

        JLabel temperature = new JLabel("10°C");
        temperature.setBounds(0, 60, 450, 60);
        temperature.setFont(new Font("Dialog", Font.BOLD, 48));
        temperature.setHorizontalAlignment(SwingConstants.CENTER);
        weatherLayer.add(temperature, Integer.valueOf(1));

        JLabel weatherConditions = new JLabel("Condition");
        weatherConditions.setBounds(0, 330, 450, 36);
        weatherConditions.setFont(new Font("Dialog", Font.PLAIN, 32));
        weatherConditions.setHorizontalAlignment(SwingConstants.CENTER);
        add(weatherConditions);

        JLabel humidityImage = new JLabel();
        try {
            humidityImage.setIcon(loadImage("src/humidity.png"));
        } catch (IOException e) {
            humidityImage.setText("\uD83D\uDCA7");
            humidityImage.setHorizontalAlignment(SwingConstants.CENTER);
            humidityImage.setFont(new Font("Dialog", Font.PLAIN, 28));
        }
        humidityImage.setBounds(100, 430, 40, 40);
        add(humidityImage);

        JLabel humidityText = new JLabel("84%");
        humidityText.setBounds(170, 430, 100, 40);
        humidityText.setFont(new Font("Dialog", Font.PLAIN, 24));
        add(humidityText);

        JLabel windspeedImage = new JLabel();
        try {
            windspeedImage.setIcon(loadImage("src/windspeed.png"));
        } catch (IOException e) {
            windspeedImage.setText("\uD83C\uDF2C️");
            windspeedImage.setHorizontalAlignment(SwingConstants.CENTER);
            windspeedImage.setFont(new Font("Dialog", Font.PLAIN, 28));
        }
        windspeedImage.setBounds(100, 490, 40, 40);
        add(windspeedImage);

        JLabel windspeedText = new JLabel("14 km/h");
        windspeedText.setBounds(170, 490, 150, 40);
        windspeedText.setFont(new Font("Dialog", Font.PLAIN, 24));
        add(windspeedText);

        JButton searchButton = new JButton(loadImage("src/search.png"));
        searchButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        searchButton.setBounds(375, 13, 47, 45);
        searchButton.addActionListener((ActionEvent e) -> {
            String userInput = searchField.getText().trim();
            if (userInput.isEmpty()) return;

            weatherData = WeatherAppGUI.getWeatherData(userInput);

            if (weatherData == null) {
                JOptionPane.showMessageDialog(null, "Unable to retrieve weather data.");
                return;
            }

            // Weather condition
            String condition = (String) weatherData.get("weatherCondition");
            try {
                switch (condition) {
                    case "Clear" -> weatherConditionImage.setIcon(loadImage("src/clear.png", 450, 217));
                    case "Cloudy" -> weatherConditionImage.setIcon(loadImage("src/cloudy.png", 450, 217));
                    case "Rain" -> weatherConditionImage.setIcon(loadImage("src/rain.png", 450, 217));
                    case "Snow" -> weatherConditionImage.setIcon(loadImage("src/snow.png", 450, 217));
                    default -> weatherConditionImage.setText("❓");
                }
            } catch (IOException ex) {
                weatherConditionImage.setText("❓");
            }

            // Update values
            double temp = (Double) weatherData.get("temperature");
            long humidity = (Long) weatherData.get("humidity");
            double windspeed = (Double) weatherData.get("windspeed");

            temperature.setText(temp + "°C");
            weatherConditions.setText(condition);
            humidityText.setText(humidity + "%");
            windspeedText.setText(windspeed + " km/h");

            try {
                humidityImage.setIcon(loadImage("src/humidity.png"));
                windspeedImage.setIcon(loadImage("src/windspeed.png"));
            } catch (IOException ex) {
                humidityImage.setText("💧");
                windspeedImage.setText("🌬️");
            }
        });
        add(searchButton);
    }

    private ImageIcon loadImage(String path, int width, int height) throws IOException {
        BufferedImage image = ImageIO.read(new File(path));
        return new ImageIcon(image.getScaledInstance(width, height, Image.SCALE_SMOOTH));
    }

    private ImageIcon loadImage(String path) throws IOException {
        return loadImage(path, 40, 40);
    }
}
